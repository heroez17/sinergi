<script type="text/javascript">
window.print();
window.onfocus=function(){window.close()}</script>
<style type="text/css" media="print">
@media print{
        @page 
        {
            size: auto;   /* auto is the current printer page size */
			margin-top:0mm;
			margin-bottom:0mm;
			
              /* this affects the margin in the printer settings */
        }

        body 
        {
			-webkit-print-color-adjust: exact;
            background-color:#FFF; 
            border: solid 1px #FFF ;
            margin: 0px;  /* the margin on the content before printing */
			font-size:10;
			font-family:BatangChe;
			
			
       }
	   table{
		   border-collapse:collapse;}
		   table,td{
			   border: 0.5px solid black;
			   text-align:right
			   }
			   table,th{
				   size:15px;
			   border: 0.5px solid black;
			   text-align:right
			   }
			   
}
    </style>


 <div class="box">
            <div class="box-header bg-red">
              
              <div class="box-tools">
                <h2 align="center">&nbsp;</h2>
                <h2 align="center">RINCIAN LAPORAN</h2>
                <p align="center">DARI<?php echo $satu.' s/d '.$dua;?></p>
                <h2 align="center"><?php echo $pro['nama']?></h2>
                <p align="center"><?php echo $pro['alamat'].' '.$pro['telpon'];?></p>
                
              </div>
            </div>
            <!-- /.box-header -->
   <div class="box-body table-responsive no-padding">

             <div class="box">
          
        
            <!-- /.box-header -->
            <div class="box-body table-responsive">
           
            
              <table id="example1" style="border-collapse:collapse;" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>TANGGAL</th>
                  <th>KEDATANGAN</th>
                  <th>PENGELUARAN</th>
                  <th>PENJUALAN</th>
                  <th>PEMASUKAN</th>
                  </tr>
                </thead>
                <tbody>
               <?php
			     $date = $satu;
    // End date
    $end_date = $dua;
  
 while (strtotime($date) <= strtotime($end_date)) {
	     $v_tanggal=$date;
        ?>
		
		 <tr>
         
              <td><?php echo $v_tanggal?></td>
                  <td>
                  <?php $carikedtangan = $this->db->query("SELECT * FROM ibenk_kassir.barang_gdg_pesan WHERE tanggal='$v_tanggal' AND stts='TERIMA'");
	if($carikedtangan->num_rows()>0){
		$rp="Rp. ";
	?>
                  
                  <table width="300">
                    <tr>
                      <td width="25">No</td>
                      <td width="62">Item</td>
                      <td width="84">Qty</td>
                      <td width="65">Harga Beli</td>
                      <td width="40">Total</td>
                    </tr>
                    <?php 
					
					$no=1;
					foreach($carikedtangan->result() as $row){?>
                    <tr>
                      <td><?php echo $no++?></td>
                      <td><?php echo $row->id_barang;?></td>
                     <td><?php echo $row->qty.' / '.$this->model_view->satuan_a($row->id_barang)?></td>
                  <td><?php echo str_replace(',','.',number_format($row->harga_beli));?></td>
                  <td><?php $tot = $row->qty*$row->harga_beli;
				   echo str_replace(',','.',number_format($tot));
				   $a=$this->db->query("SELECT SUM(harga_beli*qty) as harga_beli FROM barang_gdg_pesan WHERE tanggal='$v_tanggal'");
				  foreach($a->result() as $rowsub){
					   $totslpengeluaran=number_format($rowsub->harga_beli);
					   $v_datang=$rowsub->harga_beli;
					   
					  
					  }
				  ?></td>
                    </tr><?php } ?>
                    
                  </table>
                  <?php }else{
					  echo '-';
					  $totslpengeluaran="";
					  
					  } ?>
                  </td>
                  <td><?php echo $totslpengeluaran;
				  
				  ?></td>
          <td>
      
      
      <?php $carijual = $this->db->query("SELECT no_jual, 
	tanggal, 
	id_barang, 
	harga_jual, 
	sum(qty) as qty, 
	stts, 
	satuan, 
	usr_input
	 
	FROM 
	ibenk_kassir.barang_jual WHERE tanggal LIKE '$v_tanggal%' AND stts='SELESAI' GROUP BY id_barang,jenis ASC");
	if($carijual->num_rows()>0){
		$rp="Rp. ";
	?>
                  
                  <table width="300">
                    <tr>
                      <td width="25">No</td>
                      <td width="62">Item</td>
                      <td width="84">Qty</td>
                      <td width="65">Harga Jual</td>
                      <td width="40">Total</td>
                    </tr>
                    <?php 
					
					$no=1;
					foreach($carijual->result() as $riw){?>
                    <tr>
                      <td><?php echo $no++?></td>
                      <td><?php echo $this->model_view->baranggdg($riw->id_barang);?></td>
                     <td><?php echo $riw->qty.' / '.$riw->satuan;?></td>
                  <td><?php echo str_replace(',','.',number_format($riw->harga_jual));?></td>
                  <td><?php $totjual = $riw->qty*$riw->harga_jual;
				   echo str_replace(',','.',number_format($totjual));
				   $b=$this->db->query("SELECT SUM(harga_jual*qty) as harga_jual FROM barang_jual WHERE tanggal like '$v_tanggal%'
				   ");
				  foreach($b->result() as $riwsub){
					   $totjualsljual=number_format($riwsub->harga_jual);
					  
					  }
				  ?></td>
                    </tr><?php } ?>
                    
                  </table>
                  <?php }else{
					  echo '-';
					  $totjualsljual="";
					  
					  } ?>
                  
      
      
      
      
      
      
      
      
      
          
      </td>
                  <td><?php echo $totjualsljual ?></td>
                  </tr>
		 
		
		
		
		
		
		<?php
		$date = date ("Y-m-d", strtotime("+1 day", strtotime($date)));
        
    }
		?>
        <tr>
		   <td>&nbsp;</td>
		   <td align="right">TOTAL PENGELUARAN</td>
		   <td><?php $totalpengeluaran = $this->db->query("SELECT SUM(harga_beli*qty) as harga FROM barang_gdg_pesan WHERE tanggal BETWEEN '$satu' AND '$dua'");
		   if($totalpengeluaran->num_rows()>0){
			   foreach($totalpengeluaran->result() as $rowtotalkeluar){
				   echo number_format($rowtotalkeluar->harga);
				   }
			   }
?></td>
		   <td align="right">TOTAL PENJUALAN</td>
		   <td><?php
		   $aa=0;
		   $bb=0;
 $tglx=$satu.' 01:00:00';
		$tgl1x=$dua.' 24:00:00';

 $totalkasir = $this->db->query("SELECT SUM(harga_jual*qty) AS harga_jual FROM barang_jual WHERE jenis='gudang' AND tanggal BETWEEN '$tglx' AND '$tgl1x'");
		   if($totalkasir->num_rows()>0){
			   foreach($totalkasir->result() as $rowtotalmasuk){
				   $bb=$rowtotalmasuk->harga_jual;
				   }
			   }
			   
			   
		 $totalkasir1 = $this->db->query("SELECT SUM(harga_jual*qty) AS harga_jual FROM barang_jual WHERE jenis='pcs' AND tanggal BETWEEN '$tglx' AND '$tgl1x'");
		   if($totalkasir1->num_rows()>0){
			   foreach($totalkasir1->result() as $rowtotalmasuk1){
				   $aa=$rowtotalmasuk1->harga_jual;
				   }
			   }	
			   
			  echo number_format($aa+$bb); 	   		   
		   ?></td>
		   </tr>
		
               
               
                </tbody>
                <tfoot>
                </tfoot>
              </table>
</div>
            <!-- /.box-body -->
      </div>
             <p>&nbsp;</p>
<p>&nbsp;</p>
             <p>Tanggal Cetak : <?php echo date('d-m-Y')?></p>
   </div>
            <!-- /.box-body -->
          </div>
          
          