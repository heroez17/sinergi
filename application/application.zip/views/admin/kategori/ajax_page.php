<div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title" data-toggle="tooltip" title="KLIK MASTER DATA">DETAIL DATA</h3>
              <!-- /.box-tools -->
            </div>
          </div>